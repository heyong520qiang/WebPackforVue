<template>
  <div class="block block-2"> 
    <div class="container" flexcontainer> 
     <div class="block-item" w-375-224 aspectratio aspect-ratio="375/224"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1gRq9SXXXXXcRXFXXXXXXXXXX-375-224.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-375-224 aspectratio aspect-ratio="375/224"> 
      <div aspectratio-content=""> 
       <img src="//gw.alicdn.com/mt/TB1PMCHSXXXXXcQaXXXXXXXXXXX-375-224.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
    </div> 
    <div class="container" flexcontainer> 
     <div class="block-item" w-375-224 aspectratio aspect-ratio="375/224"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1HsjfSXXXXXcFXpXXXXXXXXXX-375-224.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-375-224 aspectratio aspect-ratio="375/224"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1qrvXSXXXXXakXFXXXXXXXXXX-375-224.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
    </div> 
   </div>
</template>

<script>
export default {
  name: 'Grid',
  data() {
    return {
      
    };
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
[w-375-224]{
  width: 375px;
}
[w-375-224]{
  aspect-ratio:'375:224';
}
</style>
