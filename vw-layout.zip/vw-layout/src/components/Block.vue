<template>
<div>
  <div class="block block-3"> 
    <div class="container" flexcontainer> 
     <div class="block-item" w-499-250 aspectratio aspect-ratio="499/250"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1Jk6lSXXXXXXSXpXXXXXXXXXX-499-250.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-250-250 aspectratio aspect-ratio="250/250"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB11E6hSXXXXXXlXpXXXXXXXXXX-250-250.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
    </div> 
    <div class="container" flexcontainer> 
     <div class="block-item" w-375-246 aspectratio aspect-ratio="375/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1N017SXXXXXcWXFXXXXXXXXXX-375-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-375-246 aspectratio aspect-ratio="375/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1rC9DSXXXXXagapXXXXXXXXXX-375-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
    </div> 
    <div class="container" flexcontainer> 
     <div class="block-item" w-375-246 aspectratio aspect-ratio="375/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1SFqYSXXXXXcDXVXXXXXXXXXX-375-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-375-246 aspectratio aspect-ratio="375/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB13DKESXXXXXarapXXXXXXXXXX-375-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
    </div> 
   </div>
	<div class="block block-3"> 
    <div class="container" flexcontainer> 
     <div class="block-item" w-750-250 aspectratio aspect-ratio="750/250"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB17hvaSXXXXXahXFXXXXXXXXXX-750-250.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
    </div> 
    <div class="container" flexcontainer> 
     <div class="block-item" w-375-246 aspectratio aspect-ratio="375/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1t7CZSXXXXXcYXVXXXXXXXXXX-375-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-375-246 aspectratio aspect-ratio="375/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1LoOOSXXXXXbPaXXXXXXXXXXX-375-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
    </div> 
    <div class="container" flexcontainer> 
     <div class="block-item" w-188-246 aspectratio aspect-ratio="188/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1Ey5WSXXXXXcJXVXXXXXXXXXX-188-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-187-246 aspectratio aspect-ratio="187/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1FuvcSXXXXXaCXFXXXXXXXXXX-187-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-188-246 aspectratio aspect-ratio="188/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB1eDK5SXXXXXXgXVXXXXXXXXXX-188-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
     <div class="block-item" w-187-246 aspectratio aspect-ratio="187/246"> 
      <div aspectratio-content> 
       <img src="//gw.alicdn.com/mt/TB16RKLSXXXXXb5aXXXXXXXXXXX-187-246.png" alt="" width="100%" height="100%"> 
      </div> 
     </div> 
    </div> 
   </div>
</div>
</template>

<script>
export default {
  name: 'Grid',
  data() {
    return {
      
    };
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
[w-750-250]{
	width: 750px;
}
[w-750-250]{
  aspect-ratio:'750:250';
}

[w-499-250]{
  width: 499px;
}
[w-499-250]{
  aspect-ratio:'499:250';
}
[w-250-250]{
	width: 250px;
}
[w-250-250]{
  aspect-ratio:'250:250';
}
[w-375-246]{
	width: 375px;
}
[w-375-246]{
	aspect-ratio:'375:246';
}
[w-188-246]{
	width: 188px;
}
[w-188-246]{
	aspect-ratio:'188:246';
}
[w-187-246]{
	width: 187px;
}
[w-187-246]{
	aspect-ratio:'187:246';
}
</style>
